/**
 * Tool Calling & Action Utilities
 */
import { ActionType, AppActionExecution } from '../types';

/**
 * Safe mathematical expression evaluator without arbitrary eval
 */
export function safeCalculate(expression: string): { success: boolean; result?: number | string; error?: string } {
  try {
    const cleaned = expression.replace(/[^0-9+\-*/().%^eE ]/g, '').trim();
    if (!cleaned) return { success: false, error: 'Empty expression' };

    // Function constructor limited strictly to arithmetic
    // eslint-disable-next-line @typescript-eslint/no-implied-eval
    const fn = new Function(`'use strict'; return (${cleaned});`);
    const val = fn();
    if (typeof val === 'number' && !Number.isNaN(val)) {
      return { success: true, result: val };
    }
    return { success: false, error: 'Invalid mathematical calculation' };
  } catch (err: any) {
    return { success: false, error: err.message || 'Calculation failed' };
  }
}

/**
 * Classifies if an action is destructive/sensitive and requires user confirmation
 */
export function isActionSensitive(type: ActionType, parameters: Record<string, any> = {}): boolean {
  switch (type) {
    case 'CREATE_FILE':
      return parameters.overwrite === true;
    case 'RUN_CODE':
      return true; // Code execution should always be acknowledged/safe
    case 'SEND_NOTIFICATION':
      return false;
    case 'OPEN_URL':
    case 'SEARCH_WEB':
    case 'CALCULATE':
    case 'READ_FILE':
    case 'OPEN_APP':
      return false;
    default:
      return false;
  }
}

/**
 * Supported built-in web and companion apps
 */
export const SUPPORTED_APPS = [
  { id: 'youtube', name: 'YouTube', url: 'https://www.youtube.com', icon: 'Youtube', color: '#ff0000', package: 'com.google.android.youtube' },
  { id: 'gmail', name: 'Gmail', url: 'https://mail.google.com', icon: 'Mail', color: '#ea4335', package: 'com.google.android.gm' },
  { id: 'google', name: 'Google', url: 'https://www.google.com', icon: 'Search', color: '#4285f4', package: 'com.google.android.googlequicksearchbox' },
  { id: 'maps', name: 'Google Maps', url: 'https://maps.google.com', icon: 'MapPin', color: '#34a853', package: 'com.google.android.apps.maps' },
  { id: 'whatsapp', name: 'WhatsApp Web', url: 'https://web.whatsapp.com', icon: 'MessageCircle', color: '#25d366', package: 'com.whatsapp' },
  { id: 'telegram', name: 'Telegram Web', url: 'https://web.telegram.org', icon: 'Send', color: '#229ed9', package: 'org.telegram.messenger' },
  { id: 'instagram', name: 'Instagram', url: 'https://www.instagram.com', icon: 'Camera', color: '#e1306c', package: 'com.instagram.android' },
  { id: 'calculator', name: 'Calculator', action: 'internal_calc', icon: 'Calculator', color: '#f59e0b', package: 'com.google.android.calculator' },
  { id: 'calendar', name: 'Google Calendar', url: 'https://calendar.google.com', icon: 'Calendar', color: '#1a73e8', package: 'com.google.android.calendar' },
  { id: 'camera', name: 'Live Camera', action: 'internal_camera', icon: 'Video', color: '#8b5cf6', package: 'com.android.camera' },
  { id: 'github', name: 'GitHub', url: 'https://github.com', icon: 'Code', color: '#6e5494', package: 'com.github.android' },
  { id: 'spotify', name: 'Spotify Web', url: 'https://open.spotify.com', icon: 'Music', color: '#1db954', package: 'com.spotify.music' }
];

/**
 * Parse structured action tags from assistant response if emitted
 * e.g. [ACTION:OPEN_URL:{"url":"https://youtube.com","title":"YouTube"}]
 */
export function parseAssistantActions(text: string): { cleanText: string; actions: AppActionExecution[] } {
  const actions: AppActionExecution[] = [];
  const regex = /\[ACTION:([A-Z_]+):(\{.*?\})\]/g;
  let cleanText = text;
  let match;

  while ((match = regex.exec(text)) !== null) {
    const type = match[1] as ActionType;
    try {
      const params = JSON.parse(match[2]);
      const requiresConfirmation = isActionSensitive(type, params);
      actions.push({
        id: `act_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
        type,
        title: params.title || `Execute ${type}`,
        description: params.description || `Execute action ${type}`,
        parameters: params,
        status: requiresConfirmation ? 'pending_confirmation' : 'executed',
        requiresConfirmation,
        timestamp: new Date().toISOString()
      });
    } catch {
      // Ignore parse failure
    }
  }

  cleanText = cleanText.replace(regex, '').trim();
  return { cleanText, actions };
}
