import test from 'node:test';
import assert from 'node:assert/strict';
import { searchMemories, findRelevantMemories, extractAutoMemoryCandidates } from './memory';
import { MemoryItem } from '../types';

const mockMemories: MemoryItem[] = [
  { id: '1', key: 'Favorite Drink', value: 'Masala Chai without sugar', category: 'preference', createdAt: '', updatedAt: '' },
  { id: '2', key: 'Assistant Name', value: 'Muskan', category: 'preference', createdAt: '', updatedAt: '' },
  { id: '3', key: 'Current Goal', value: 'Complete the AI application for startup launch', category: 'work', createdAt: '', updatedAt: '' },
];

test('searchMemories matches keywords across key, value and category', () => {
  const r1 = searchMemories(mockMemories, 'chai');
  assert.equal(r1.length, 1);
  assert.equal(r1[0].key, 'Favorite Drink');

  const r2 = searchMemories(mockMemories, 'work');
  assert.equal(r2.length, 1);
  assert.equal(r2[0].key, 'Current Goal');

  const r3 = searchMemories(mockMemories, '');
  assert.equal(r3.length, 3);
});

test('findRelevantMemories scores context matching', () => {
  const matches = findRelevantMemories(mockMemories, 'I really need some chai right now');
  assert.ok(matches.length > 0);
  assert.equal(matches[0].key, 'Favorite Drink');
});

test('extractAutoMemoryCandidates extracts favorite and remember patterns', () => {
  const m1 = extractAutoMemoryCandidates('My favorite food is Biryani');
  assert.ok(m1);
  assert.equal(m1.key, 'Favorite food');
  assert.equal(m1.value, 'Biryani');

  const m2 = extractAutoMemoryCandidates('Please remember that I have an interview tomorrow at 10 AM');
  assert.ok(m2);
  assert.equal(m2.key, 'User Instruction');
  assert.equal(m2.value, 'I have an interview tomorrow at 10 AM');
});
