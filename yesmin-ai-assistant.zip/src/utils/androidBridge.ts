/**
 * Android WebView / Companion Bridge Architecture
 * 
 * Flow:
 * Web App -> window.AndroidBridge / Intent Schemes -> Android Native Action Manager -> Device API
 */

export interface AndroidBridgeInterface {
  postMessage?: (msg: string) => void;
  openApp?: (packageName: string, uri?: string) => boolean;
  makePhoneCall?: (phoneNumber: string) => void;
  sendSMS?: (phoneNumber: string, message: string) => void;
  triggerVibration?: (milliseconds: number) => void;
  speakNative?: (text: string, language: string) => void;
}

declare global {
  interface Window {
    AndroidBridge?: AndroidBridgeInterface;
    webkit?: {
      messageHandlers?: {
        AndroidBridge?: {
          postMessage: (msg: any) => void;
        };
      };
    };
  }
}

export class DeviceBridge {
  static isAndroidWebView(): boolean {
    return (
      typeof window !== 'undefined' &&
      (!!window.AndroidBridge ||
        !!window.webkit?.messageHandlers?.AndroidBridge ||
        /Android.*wv/.test(navigator.userAgent))
    );
  }

  static executeAction(actionType: string, payload: Record<string, any>): {
    dispatched: boolean;
    channel: 'native_bridge' | 'browser_fallback' | 'intent_uri';
    details: string;
  } {
    if (typeof window === 'undefined') {
      return { dispatched: false, channel: 'browser_fallback', details: 'SSR environment' };
    }

    // 1. Check native AndroidBridge
    if (window.AndroidBridge) {
      try {
        const msg = JSON.stringify({ action: actionType, payload, timestamp: Date.now() });
        if (typeof window.AndroidBridge.postMessage === 'function') {
          window.AndroidBridge.postMessage(msg);
          return { dispatched: true, channel: 'native_bridge', details: 'Dispatched to AndroidBridge.postMessage' };
        }
      } catch (err: any) {
        console.warn('AndroidBridge error:', err);
      }
    }

    // 2. Specific intent or web URI fallback
    if (actionType === 'OPEN_APP' || actionType === 'OPEN_URL') {
      const url = payload.url || '';
      const pkg = payload.package || '';

      if (url) {
        window.open(url, '_blank', 'noopener,noreferrer');
        return { dispatched: true, channel: 'browser_fallback', details: `Opened URL: ${url}` };
      }

      if (pkg) {
        // Fallback to Android intent URL in mobile Chrome
        const intentUrl = `intent://#Intent;package=${pkg};scheme=https;end`;
        window.location.href = intentUrl;
        return { dispatched: true, channel: 'intent_uri', details: `Dispatched Android Intent for ${pkg}` };
      }
    }

    return { dispatched: false, channel: 'browser_fallback', details: 'Browser security constraints enforced; action logged' };
  }
}
