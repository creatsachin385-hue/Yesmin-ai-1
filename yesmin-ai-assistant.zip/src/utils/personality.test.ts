import test from 'node:test';
import assert from 'node:assert/strict';
import {
  DEFAULT_ASSISTANT_NAME,
  DEFAULT_NICKNAME,
  generateGreeting,
  getEffectiveAssistantName,
  getEffectiveNickname,
  buildSystemPrompt,
} from './personality';
import { AssistantSettings } from '../types';

test('assistant name fallback and custom name support', () => {
  assert.equal(getEffectiveAssistantName(''), DEFAULT_ASSISTANT_NAME);
  assert.equal(getEffectiveAssistantName('  '), DEFAULT_ASSISTANT_NAME);
  assert.equal(getEffectiveAssistantName('Muskan'), 'Muskan');
  assert.equal(getEffectiveAssistantName('Jarvis X'), 'Jarvis X');
});

test('nickname fallback and custom nickname support', () => {
  assert.equal(getEffectiveNickname(''), DEFAULT_NICKNAME);
  assert.equal(getEffectiveNickname('Sachin'), 'Sachin');
});

test('generateGreeting incorporates custom assistant name and nickname', () => {
  const greeting = generateGreeting('Muskan', 'Sachin', 'girlfriend');
  assert.ok(greeting.includes('Sachin'));
  assert.ok(greeting.includes('Muskan'));

  const jarvisGreeting = generateGreeting('Jarvis', 'Boss', 'professional');
  assert.ok(jarvisGreeting.includes('Jarvis'));
  assert.ok(jarvisGreeting.includes('Boss'));
});

test('buildSystemPrompt injects custom identity and memories', () => {
  const settings: AssistantSettings = {
    assistantName: 'Muskan AI',
    userNickname: 'Mere Jaan',
    personalityMode: 'girlfriend',
    greetingStyle: 'romantic',
    customInstructions: 'Speak 60% Hinglish and be extra motivating.',
    systemPromptMode: 'preset',
    voiceProvider: 'browser',
    voiceName: 'Default',
    voiceSpeed: 1,
    autoSpeak: false,
    volume: 1,
    liveVoiceModel: 'gemini-3.8-live',
    liveVoiceName: 'Zephyr',
    interruptMode: true,
    language: 'hinglish',
    activeProvider: 'gemini',
    geminiModel: 'gemini-3.8-flash',
    temperature: 0.7,
    maxOutputTokens: 2000,
    theme: 'dark',
    accentColor: 'pink',
    glowIntensity: 'vibrant',
    animationIntensity: 'medium',
    memoryEnabled: true,
    micPermission: true,
    notifPermission: true,
    cameraPermission: true,
  };

  const memories = [
    {
      id: 'm1',
      key: 'Project',
      value: 'Building full-stack app with React',
      category: 'work' as const,
      createdAt: '',
      updatedAt: '',
    },
  ];

  const prompt = buildSystemPrompt(settings, memories);
  assert.ok(prompt.includes('Muskan AI'));
  assert.ok(prompt.includes('Mere Jaan'));
  assert.ok(prompt.includes('Speak 60% Hinglish'));
  assert.ok(prompt.includes('Building full-stack app with React'));
});
