/**
 * Yesmin AI & Jarvis Assistant - Types Definition
 */

export type PersonalityMode =
  | 'girlfriend'
  | 'friendly'
  | 'professional'
  | 'coding'
  | 'study';

export type GreetingStyle = 'romantic' | 'casual' | 'formal' | 'poetic' | 'energetic';

export type VoiceProvider = 'gemini' | 'elevenlabs' | 'browser';

export type AIProviderId = 'gemini' | 'openai' | 'anthropic' | 'custom';

export type ThemeMode = 'dark' | 'light' | 'system';

export type AccentColor = 'pink' | 'purple' | 'cyan' | 'emerald' | 'amber';

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  nickname: string;
  avatarUrl?: string;
  createdAt: string;
}

export interface AssistantSettings {
  assistantName: string; // Default "YESMIN AI"
  userNickname: string;  // Default "Jaan"
  personalityMode: PersonalityMode;
  greetingStyle: GreetingStyle;
  customInstructions: string;
  avatarUrl?: string;
  
  // Voice
  voiceProvider: VoiceProvider;
  voiceName: string;
  voiceSpeed: number; // 0.5 to 2.0
  autoSpeak: boolean;
  volume: number;

  // Live Voice
  liveVoiceModel: string;
  liveVoiceName: string;
  interruptMode: boolean;
  language: 'hindi' | 'hinglish' | 'english';

  // AI Model
  activeProvider: AIProviderId;
  geminiModel: string;
  temperature: number;
  maxOutputTokens: number;

  // Appearance
  theme: ThemeMode;
  accentColor: AccentColor;
  glowIntensity: 'subtle' | 'vibrant' | 'ultra';
  animationIntensity: 'low' | 'medium' | 'high';

  // Memory & Permissions
  memoryEnabled: boolean;
  micPermission: boolean;
  notifPermission: boolean;
  cameraPermission: boolean;
}

export interface ElevenLabsConfig {
  apiKey: string;
  voiceId: string;
  modelId: string;
  stability: number;
  similarity: number;
  style: number;
  speed: number;
  enabled: boolean;
}

export interface ProviderConfig {
  id: AIProviderId;
  name: string;
  enabled: boolean;
  apiKey: string;
  baseUrl?: string;
  model: string;
  status: 'connected' | 'disconnected' | 'testing' | 'error';
  lastTested?: string;
  error?: string;
}

export interface ServiceConfig {
  id: string;
  name: string;
  category: string;
  enabled: boolean;
  apiKey?: string;
  endpoint?: string;
  options?: Record<string, any>;
  status: 'connected' | 'not_configured' | 'error';
  lastTested?: string;
}

export interface ChatMessage {
  id: string;
  conversationId: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: string;
  audioUrl?: string;
  attachments?: {
    name: string;
    type: string;
    size?: number;
    url?: string;
    dataUrl?: string;
  }[];
  actions?: AppActionExecution[];
  isStreaming?: boolean;
}

export interface Conversation {
  id: string;
  title: string;
  createdAt: string;
  updatedAt: string;
  projectId?: string;
  summary?: string;
  pinned?: boolean;
}

export interface MemoryItem {
  id: string;
  key: string;
  value: string;
  category: 'preference' | 'personal' | 'work' | 'instruction' | 'companion';
  createdAt: string;
  updatedAt: string;
  source?: string;
}

export type ActionType =
  | 'OPEN_URL'
  | 'OPEN_APP'
  | 'SEARCH_WEB'
  | 'CREATE_FILE'
  | 'READ_FILE'
  | 'RUN_CODE'
  | 'SEND_NOTIFICATION'
  | 'CALCULATE'
  | 'OTHER_SUPPORTED_ACTIONS';

export interface AppActionExecution {
  id: string;
  type: ActionType;
  title: string;
  description: string;
  parameters: Record<string, any>;
  status: 'pending_confirmation' | 'executed' | 'cancelled' | 'failed';
  requiresConfirmation: boolean;
  result?: any;
  timestamp: string;
}

export interface ProjectFile {
  id: string;
  path: string;
  name: string;
  content: string;
  language: string;
  updatedAt: string;
}

export interface Project {
  id: string;
  name: string;
  description: string;
  type: 'android_app' | 'website' | 'ai_assistant' | 'coding' | 'youtube' | 'study' | 'custom';
  createdAt: string;
  updatedAt: string;
  files: ProjectFile[];
  notes?: string;
  instructions?: string;
}

export interface TaskItem {
  id: string;
  title: string;
  description?: string;
  completed: boolean;
  priority: 'low' | 'medium' | 'high';
  dueDate?: string;
  reminder?: boolean;
  createdAt: string;
  projectId?: string;
}

export interface SearchResultItem {
  title: string;
  url: string;
  snippet: string;
  source: string;
}
