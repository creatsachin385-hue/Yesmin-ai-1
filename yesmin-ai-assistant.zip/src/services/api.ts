/**
 * API Service for Backend Communication
 */
import { AssistantSettings, UserProfile, Conversation, ChatMessage, MemoryItem, Project, TaskItem, SearchResultItem } from '../types';

export const api = {
  // Settings & User
  async getSettings(): Promise<{ settings: AssistantSettings; user: UserProfile }> {
    const res = await fetch('/api/settings');
    if (!res.ok) throw new Error('Failed to load settings');
    return res.json();
  },

  async saveSettings(settings: Partial<AssistantSettings>): Promise<{ success: boolean; settings: AssistantSettings }> {
    const res = await fetch('/api/settings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(settings),
    });
    if (!res.ok) throw new Error('Failed to save settings');
    return res.json();
  },

  // Auth
  async login(email: string): Promise<{ success: boolean; user: UserProfile }> {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email }),
    });
    if (!res.ok) throw new Error('Failed to login');
    return res.json();
  },

  async register(name: string, email: string, nickname: string): Promise<{ success: boolean; user: UserProfile }> {
    const res = await fetch('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, email, nickname }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Failed to register');
    }
    return res.json();
  },

  // Conversations
  async getConversations(): Promise<Conversation[]> {
    const res = await fetch('/api/conversations');
    const data = await res.json();
    return data.conversations || [];
  },

  async createConversation(title?: string): Promise<Conversation> {
    const res = await fetch('/api/conversations', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title }),
    });
    const data = await res.json();
    return data.conversation;
  },

  async deleteConversation(id: string): Promise<void> {
    await fetch(`/api/conversations/${id}`, { method: 'DELETE' });
  },

  async getMessages(conversationId: string): Promise<ChatMessage[]> {
    const res = await fetch(`/api/conversations/${conversationId}/messages`);
    const data = await res.json();
    return data.messages || [];
  },

  async saveMessage(conversationId: string, message: Partial<ChatMessage>): Promise<ChatMessage> {
    const res = await fetch(`/api/conversations/${conversationId}/messages`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(message),
    });
    const data = await res.json();
    return data.message;
  },

  async deleteMessage(id: string): Promise<void> {
    await fetch(`/api/messages/${id}`, { method: 'DELETE' });
  },

  // Chat AI Generation
  async generateChat(payload: {
    conversationId?: string;
    prompt: string;
    history?: { role: string; content: string }[];
    systemInstruction?: string;
    images?: { base64: string; mimeType: string }[];
  }): Promise<string> {
    const res = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...payload, stream: false }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Chat generation failed');
    }
    const data = await res.json();
    return data.text || '';
  },

  // Memories
  async getMemories(): Promise<MemoryItem[]> {
    const res = await fetch('/api/memories');
    const data = await res.json();
    return data.memories || [];
  },

  async createMemory(key: string, value: string, category: string): Promise<MemoryItem> {
    const res = await fetch('/api/memories', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ key, value, category }),
    });
    const data = await res.json();
    return data.memory;
  },

  async updateMemory(id: string, data: Partial<MemoryItem>): Promise<MemoryItem> {
    const res = await fetch(`/api/memories/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    const resData = await res.json();
    return resData.memory;
  },

  async deleteMemory(id: string): Promise<void> {
    await fetch(`/api/memories/${id}`, { method: 'DELETE' });
  },

  async clearMemories(): Promise<void> {
    await fetch('/api/memories', { method: 'DELETE' });
  },

  // Projects
  async getProjects(): Promise<Project[]> {
    const res = await fetch('/api/projects');
    const data = await res.json();
    return data.projects || [];
  },

  async createProject(name: string, description: string, type: string): Promise<Project> {
    const res = await fetch('/api/projects', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, description, type }),
    });
    const data = await res.json();
    return data.project;
  },

  async updateProject(id: string, update: Partial<Project>): Promise<Project> {
    const res = await fetch(`/api/projects/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(update),
    });
    const data = await res.json();
    return data.project;
  },

  async deleteProject(id: string): Promise<void> {
    await fetch(`/api/projects/${id}`, { method: 'DELETE' });
  },

  // Code Sandbox
  async runSandboxCode(code: string, language = 'javascript'): Promise<{
    success: boolean;
    exitCode?: number;
    stdout: string;
    stderr: string;
    error?: string;
  }> {
    const res = await fetch('/api/sandbox/run', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ code, language }),
    });
    return res.json();
  },

  // Tasks
  async getTasks(): Promise<TaskItem[]> {
    const res = await fetch('/api/tasks');
    const data = await res.json();
    return data.tasks || [];
  },

  async createTask(task: Partial<TaskItem>): Promise<TaskItem> {
    const res = await fetch('/api/tasks', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(task),
    });
    const data = await res.json();
    return data.task;
  },

  async updateTask(id: string, update: Partial<TaskItem>): Promise<TaskItem> {
    const res = await fetch(`/api/tasks/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(update),
    });
    const data = await res.json();
    return data.task;
  },

  async deleteTask(id: string): Promise<void> {
    await fetch(`/api/tasks/${id}`, { method: 'DELETE' });
  },

  // Web Search
  async searchWeb(query: string): Promise<SearchResultItem[]> {
    const res = await fetch(`/api/search?q=${encodeURIComponent(query)}`);
    const data = await res.json();
    return data.results || [];
  },

  // ElevenLabs TTS
  async synthesizeElevenLabs(text: string, apiKey?: string, voiceId?: string): Promise<Blob> {
    const res = await fetch('/api/tts/elevenlabs', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text, apiKey, voiceId }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'ElevenLabs failed');
    }
    return res.blob();
  },

  // Provider Test
  async testProvider(provider: string, apiKey?: string, model?: string): Promise<any> {
    const res = await fetch('/api/providers/test', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ provider, apiKey, model }),
    });
    return res.json();
  },
};
