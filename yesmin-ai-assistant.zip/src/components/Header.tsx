import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Sparkles, Volume2, VolumeX, Shield, Radio, Tablet } from 'lucide-react';
import { getEffectiveAssistantName, getEffectiveNickname } from '../utils/personality';
import { TabletInstallModal } from './TabletInstallModal';

export const Header: React.FC = () => {
  const { settings, updateSettings, setActiveTab, activeTab, assistantStatus } = useApp();
  const [showTabletModal, setShowTabletModal] = useState(false);

  const assistantName = getEffectiveAssistantName(settings.assistantName);
  const nickname = getEffectiveNickname(settings.userNickname);

  const modeBadge = {
    girlfriend: { label: 'Companion ❤️', color: 'bg-pink-500/20 text-pink-300 border-pink-500/30' },
    friendly: { label: 'Best Friend ✨', color: 'bg-purple-500/20 text-purple-300 border-purple-500/30' },
    professional: { label: 'Jarvis Executive ⚡', color: 'bg-blue-500/20 text-blue-300 border-blue-500/30' },
    coding: { label: 'Dev Agent 💻', color: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30' },
    study: { label: 'Study Tutor 🎓', color: 'bg-amber-500/20 text-amber-300 border-amber-500/30' },
  }[settings.personalityMode || 'girlfriend'];

  const toggleAutoSpeak = () => {
    updateSettings({ autoSpeak: !settings.autoSpeak });
  };

  return (
    <header className="sticky top-0 z-30 h-16 w-full border-b border-purple-900/40 bg-slate-950/70 backdrop-blur-xl px-4 sm:px-6 flex items-center justify-between">
      {/* Left: Assistant Identity */}
      <div className="flex items-center gap-3">
        <button
          onClick={() => setActiveTab('home')}
          className="flex items-center gap-2.5 text-left group transition-all"
        >
          <div className="relative">
            <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-pink-500 to-purple-600 flex items-center justify-center shadow-[0_0_15px_rgba(236,72,153,0.5)] group-hover:scale-105 transition-transform">
              <Sparkles className="w-4 h-4 text-white" />
            </div>
            <span
              className={`absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full border-2 border-slate-950 ${
                assistantStatus !== 'idle' ? 'bg-emerald-400 animate-ping' : 'bg-emerald-500'
              }`}
            />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base sm:text-lg font-bold tracking-tight text-white group-hover:text-pink-300 transition-colors">
                {assistantName}
              </h1>
              <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full border hidden sm:inline-block ${modeBadge.color}`}>
                {modeBadge.label}
              </span>
            </div>
            <p className="text-[11px] text-slate-400 hidden sm:block">
              Serving <span className="text-pink-400 font-medium">{nickname}</span>
            </p>
          </div>
        </button>
      </div>

      {/* Right Controls */}
      <div className="flex items-center gap-2 sm:gap-3">
        {/* Live Voice Shortcut Button */}
        {activeTab !== 'live' && (
          <button
            onClick={() => setActiveTab('live')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 hover:to-purple-500 text-white text-xs font-semibold shadow-lg shadow-pink-500/20 active:scale-95 transition-all"
          >
            <Radio className="w-3.5 h-3.5 animate-pulse" />
            <span className="hidden sm:inline">Start</span> Live Call
          </button>
        )}

        {/* Auto-Speak Toggle */}
        <button
          onClick={toggleAutoSpeak}
          title={settings.autoSpeak ? 'Auto-Voice Enabled' : 'Auto-Voice Disabled'}
          className={`p-2 rounded-xl border transition-all ${
            settings.autoSpeak
              ? 'bg-purple-900/40 border-purple-500/50 text-pink-400 shadow-[0_0_10px_rgba(236,72,153,0.3)]'
              : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:text-slate-200'
          }`}
        >
          {settings.autoSpeak ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
        </button>

        {/* Install on Tablet / Mobile Button */}
        <button
          onClick={() => setShowTabletModal(true)}
          title="Install on Samsung Galaxy Tab / Mobile"
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-pink-500/40 bg-pink-500/10 hover:bg-pink-500/20 text-pink-300 text-xs font-semibold shadow transition-all active:scale-95"
        >
          <Tablet className="w-3.5 h-3.5 text-pink-400" />
          <span className="hidden sm:inline">Install on Tab</span>
        </button>

        {/* Quick Settings Shortcut */}
        <button
          onClick={() => setActiveTab('settings')}
          className="flex items-center gap-2 px-2.5 py-1.5 rounded-xl border border-slate-800 bg-slate-900/60 hover:bg-slate-800/80 text-xs text-slate-300 transition-all"
        >
          <div className="w-5 h-5 rounded-full bg-pink-500/20 text-pink-400 flex items-center justify-center font-bold text-[10px]">
            {nickname.charAt(0).toUpperCase()}
          </div>
          <span className="hidden sm:inline">{nickname}</span>
        </button>
      </div>

      {/* Tablet Install Guide Modal */}
      <TabletInstallModal
        isOpen={showTabletModal}
        onClose={() => setShowTabletModal(false)}
      />
    </header>
  );
};
