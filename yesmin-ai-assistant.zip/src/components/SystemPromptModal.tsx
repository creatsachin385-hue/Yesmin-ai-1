import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import {
  SYSTEM_PROMPT_PRESETS,
  buildSystemPrompt,
  getEffectiveAssistantName,
  getEffectiveNickname,
} from '../utils/personality';
import {
  X,
  Sparkles,
  Terminal,
  Save,
  RotateCcw,
  Copy,
  Check,
  Eye,
  Edit3,
  HelpCircle,
  FileCode,
  ShieldAlert,
  Zap,
} from 'lucide-react';

interface SystemPromptModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SystemPromptModal: React.FC<SystemPromptModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { settings, updateSettings, showToast } = useApp();

  const assistantName = getEffectiveAssistantName(settings.assistantName);
  const nickname = getEffectiveNickname(settings.userNickname);

  const [activeTab, setActiveTab] = useState<'editor' | 'preview'>('editor');
  const [selectedPresetId, setSelectedPresetId] = useState<string>(
    settings.activePromptPreset || 'girlfriend_romantic'
  );

  const [promptText, setPromptText] = useState<string>(
    settings.customSystemPrompt ||
      SYSTEM_PROMPT_PRESETS.find((p) => p.id === selectedPresetId)?.prompt ||
      SYSTEM_PROMPT_PRESETS[0].prompt
  );

  const [copied, setCopied] = useState(false);
  const [isCustomMode, setIsCustomMode] = useState<boolean>(
    settings.systemPromptMode === 'custom'
  );

  useEffect(() => {
    if (isOpen) {
      if (settings.systemPromptMode === 'custom' && settings.customSystemPrompt) {
        setPromptText(settings.customSystemPrompt);
        setIsCustomMode(true);
      } else {
        const found = SYSTEM_PROMPT_PRESETS.find(
          (p) => p.id === (settings.activePromptPreset || 'girlfriend_romantic')
        );
        if (found) {
          setPromptText(found.prompt);
          setSelectedPresetId(found.id);
        }
      }
    }
  }, [isOpen, settings]);

  if (!isOpen) return null;

  const handleSelectPreset = (presetId: string) => {
    setSelectedPresetId(presetId);
    const found = SYSTEM_PROMPT_PRESETS.find((p) => p.id === presetId);
    if (found) {
      setPromptText(found.prompt);
      setIsCustomMode(false);
    }
  };

  const handleInsertVariable = (variable: string) => {
    setPromptText((prev) => prev + variable);
    setIsCustomMode(true);
    showToast(`Inserted ${variable}`, 'info');
  };

  const handleSave = async () => {
    await updateSettings({
      systemPromptMode: 'custom',
      customSystemPrompt: promptText,
      activePromptPreset: selectedPresetId,
    });
    setIsCustomMode(true);
    showToast('System Prompt saved & applied to Yesmin AI!', 'success');
  };

  const handleReset = async () => {
    const defaultPreset = SYSTEM_PROMPT_PRESETS[0];
    setSelectedPresetId(defaultPreset.id);
    setPromptText(defaultPreset.prompt);
    setIsCustomMode(false);
    await updateSettings({
      systemPromptMode: 'preset',
      activePromptPreset: defaultPreset.id,
      customSystemPrompt: undefined,
    });
    showToast('Reset to original default System Prompt', 'info');
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(promptText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    showToast('System prompt copied to clipboard', 'info');
  };

  // Compile prompt preview with active variables
  const compiledPreview = promptText
    .replace(/\{\{assistantName\}\}/gi, assistantName)
    .replace(/\{\{userNickname\}\}/gi, nickname)
    .replace(/\{\{language\}\}/gi, settings.language || 'hinglish')
    .replace(/\{\{dateTime\}\}/gi, new Date().toLocaleString())
    .replace(
      /\{\{memories\}\}/gi,
      settings.memoryEnabled
        ? `\nRELEVANT PERSISTENT USER MEMORY:\n- User Nickname: ${nickname}\n- Preferred Language: ${settings.language || 'hinglish'}`
        : ''
    );

  const charCount = promptText.length;
  const tokenEstimate = Math.ceil(charCount / 4);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-4xl max-h-[92vh] flex flex-col rounded-2xl border border-purple-500/40 bg-slate-950/95 shadow-2xl shadow-purple-950/80 overflow-hidden">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-purple-900/30 bg-gradient-to-r from-purple-950/40 via-slate-900 to-pink-950/30 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-pink-500 to-purple-600 flex items-center justify-center text-white shadow-lg shadow-pink-500/30">
              <Terminal className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-bold text-white tracking-wide">
                  System Prompt Studio
                </h2>
                <span className="text-[10px] px-2 py-0.5 rounded-full border border-pink-500/30 bg-pink-500/10 text-pink-300 font-mono">
                  Full Access
                </span>
              </div>
              <p className="text-xs text-slate-400">
                You have 100% full control over Yesmin AI's internal instructions, character, and response rules.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Preset Selector */}
        <div className="px-4 py-3 border-b border-slate-800/80 bg-slate-900/40 overflow-x-auto">
          <div className="flex items-center gap-2 min-w-max">
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider mr-1">
              Presets:
            </span>
            {SYSTEM_PROMPT_PRESETS.map((preset) => {
              const active = selectedPresetId === preset.id && !isCustomMode;
              return (
                <button
                  key={preset.id}
                  onClick={() => handleSelectPreset(preset.id)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${
                    active
                      ? 'bg-pink-600/20 border-pink-500 text-pink-300 shadow-sm shadow-pink-500/20'
                      : 'bg-slate-900/80 border-slate-800 text-slate-300 hover:bg-slate-800 hover:text-white'
                  }`}
                >
                  <span>{preset.icon}</span>
                  <span>{preset.name.split('-')[0].trim()}</span>
                </button>
              );
            })}
            <button
              onClick={() => setIsCustomMode(true)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${
                isCustomMode
                  ? 'bg-purple-600/30 border-purple-500 text-purple-300'
                  : 'bg-slate-900/80 border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              <span>✏️</span>
              <span>Custom Mode</span>
            </button>
          </div>
        </div>

        {/* Variable Helper Bar */}
        <div className="px-4 py-2 border-b border-slate-800/60 bg-slate-950/60 flex flex-wrap items-center justify-between gap-2 text-xs">
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="text-[11px] text-slate-400 font-medium mr-1">
              Click to insert tag:
            </span>
            {[
              { label: '{{assistantName}}', desc: assistantName },
              { label: '{{userNickname}}', desc: nickname },
              { label: '{{memories}}', desc: 'Saved facts' },
              { label: '{{language}}', desc: settings.language || 'hinglish' },
              { label: '{{dateTime}}', desc: 'Now' },
            ].map((v) => (
              <button
                key={v.label}
                onClick={() => handleInsertVariable(v.label)}
                title={`Inserts current ${v.desc}`}
                className="px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-[11px] font-mono text-pink-400 hover:bg-pink-500/10 hover:border-pink-500/30 transition-all"
              >
                {v.label}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('editor')}
              className={`flex items-center gap-1 px-2.5 py-1 rounded text-xs font-medium transition-all ${
                activeTab === 'editor'
                  ? 'bg-pink-600/20 text-pink-300 border border-pink-500/30'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Edit3 className="w-3.5 h-3.5" /> Editor
            </button>
            <button
              onClick={() => setActiveTab('preview')}
              className={`flex items-center gap-1 px-2.5 py-1 rounded text-xs font-medium transition-all ${
                activeTab === 'preview'
                  ? 'bg-purple-600/20 text-purple-300 border border-purple-500/30'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Eye className="w-3.5 h-3.5" /> Compiled Preview
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5">
          {activeTab === 'editor' ? (
            <div className="space-y-3">
              <div className="relative">
                <textarea
                  value={promptText}
                  onChange={(e) => {
                    setPromptText(e.target.value);
                    setIsCustomMode(true);
                  }}
                  rows={16}
                  placeholder="Enter system prompt for Yesmin AI..."
                  className="w-full font-mono text-xs sm:text-sm text-slate-200 bg-slate-900/90 border border-slate-800 rounded-xl p-4 focus:outline-none focus:border-pink-500/60 focus:ring-1 focus:ring-pink-500/40 transition-all leading-relaxed resize-none shadow-inner"
                  spellCheck={false}
                />
              </div>

              {/* Stats Bar */}
              <div className="flex items-center justify-between text-[11px] text-slate-400 px-1">
                <div className="flex items-center gap-3">
                  <span>Characters: <strong className="text-slate-300">{charCount}</strong></span>
                  <span>Est. Tokens: <strong className="text-pink-400">~{tokenEstimate}</strong></span>
                </div>
                <div className="flex items-center gap-1.5 text-slate-500">
                  <HelpCircle className="w-3.5 h-3.5" />
                  <span>Will be sent to AI as the highest-priority root directive</span>
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-3">
              <div className="p-3 rounded-lg bg-purple-950/20 border border-purple-800/30 text-xs text-purple-300">
                Below is the exact compiled text prompt that the AI model receives, with all variables (assistant name, nickname, and memories) injected.
              </div>
              <pre className="font-mono text-xs sm:text-sm text-slate-200 bg-slate-900/90 border border-slate-800 rounded-xl p-4 overflow-x-auto whitespace-pre-wrap leading-relaxed shadow-inner">
                {compiledPreview}
              </pre>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="p-4 border-t border-slate-800/80 bg-slate-950 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <button
              onClick={handleReset}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl border border-slate-800 text-xs font-semibold text-slate-400 hover:text-white hover:bg-slate-900 transition-all"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              Reset Default
            </button>
            <button
              onClick={handleCopy}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl border border-slate-800 text-xs font-semibold text-slate-400 hover:text-white hover:bg-slate-900 transition-all"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              {copied ? 'Copied!' : 'Copy Prompt'}
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-xl border border-slate-800 text-xs font-semibold text-slate-300 hover:bg-slate-900 transition-all"
            >
              Cancel
            </button>
            <button
              onClick={async () => {
                await handleSave();
                onClose();
              }}
              className="flex items-center gap-1.5 px-5 py-2 rounded-xl bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 hover:to-purple-500 text-xs font-bold text-white shadow-lg shadow-pink-500/20 active:scale-95 transition-all"
            >
              <Save className="w-3.5 h-3.5" />
              Save &amp; Apply System Prompt
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
