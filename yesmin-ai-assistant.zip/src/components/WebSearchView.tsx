import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { api } from '../services/api';
import { SearchResultItem } from '../types';
import { getEffectiveAssistantName } from '../utils/personality';
import {
  Search,
  ExternalLink,
  Sparkles,
  Clock,
  BookOpen,
  ArrowRight,
  RefreshCw,
  Globe,
} from 'lucide-react';

export const WebSearchView: React.FC = () => {
  const { settings, setActiveTab, showToast } = useApp();
  const assistantName = getEffectiveAssistantName(settings.assistantName);

  const [query, setQuery] = useState('');
  const [results, setResults] = useState<SearchResultItem[]>([]);
  const [searchHistory, setSearchHistory] = useState<string[]>([
    'Latest advancements in AI and Gemini models',
    'Full-stack TypeScript best practices',
  ]);
  const [isSearching, setIsSearching] = useState(false);
  const [summaries, setSummaries] = useState<Record<number, string>>({});
  const [summarizingIdx, setSummarizingIdx] = useState<number | null>(null);

  const handleSearch = async (targetQuery?: string) => {
    const q = targetQuery || query;
    if (!q.trim()) return;

    setIsSearching(true);
    setSummaries({});

    try {
      const data = await api.searchWeb(q);
      setResults(data);

      if (!searchHistory.includes(q)) {
        setSearchHistory((prev) => [q, ...prev.slice(0, 9)]);
      }

      showToast(`Found ${data.length} search results`, 'info');
    } catch (err: any) {
      showToast(err.message || 'Search failed', 'error');
    } finally {
      setIsSearching(false);
    }
  };

  const handleSummarize = async (index: number, result: SearchResultItem) => {
    setSummarizingIdx(index);
    try {
      const prompt = `Please provide a clear, concise 2-sentence executive summary of the following web result for the user:
Title: "${result.title}"
Source: "${result.source}"
Snippet: "${result.snippet}"`;

      const summaryText = await api.generateChat({ prompt });
      setSummaries((prev) => ({ ...prev, [index]: summaryText }));
    } catch (err: any) {
      showToast('Failed to summarize result', 'error');
    } finally {
      setSummarizingIdx(null);
    }
  };

  const handleAskInChat = (result: SearchResultItem) => {
    const prompt = `Regarding this web result from "${result.source}": "${result.title}" (${result.snippet}), what are your thoughts and deep analysis?`;
    sessionStorage.setItem('pending_quick_prompt', prompt);
    setActiveTab('chat');
  };

  return (
    <div className="flex-1 overflow-y-auto px-4 py-6 sm:px-8 max-w-5xl mx-auto space-y-6 pb-24 md:pb-12">
      {/* Header & Search Bar */}
      <div className="p-6 rounded-3xl bg-slate-900/60 border border-purple-900/40 backdrop-blur-xl space-y-4">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Globe className="w-5 h-5 text-cyan-400" />
            Live Web Search
          </h2>
          <p className="text-xs text-slate-400">
            Real-time web discovery with source verification and AI-grounded summaries.
          </p>
        </div>

        {/* Input Bar */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSearch();
          }}
          className="flex items-center gap-2"
        >
          <div className="flex-1 relative flex items-center">
            <Search className="w-4 h-4 text-slate-500 absolute left-3.5" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search websites, news, docs, articles..."
              className="w-full pl-10 pr-4 py-3 text-sm rounded-2xl bg-slate-950 border border-purple-800/40 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 shadow-inner"
            />
          </div>

          <button
            type="submit"
            disabled={isSearching || !query.trim()}
            className="px-6 py-3 rounded-2xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 text-white text-xs font-semibold shadow-lg shadow-cyan-500/20 active:scale-95 transition-all flex items-center gap-2 disabled:opacity-40"
          >
            {isSearching ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
            <span>Search</span>
          </button>
        </form>

        {/* Search History Chips */}
        {searchHistory.length > 0 && (
          <div className="flex items-center gap-2 overflow-x-auto pt-1 pb-1">
            <span className="text-[11px] text-slate-500 flex items-center gap-1 shrink-0">
              <Clock className="w-3 h-3" /> Recent:
            </span>
            {searchHistory.slice(0, 4).map((hist, i) => (
              <button
                key={i}
                onClick={() => {
                  setQuery(hist);
                  handleSearch(hist);
                }}
                className="text-[11px] px-2.5 py-1 rounded-full bg-slate-800/60 hover:bg-slate-700 border border-slate-700/60 text-slate-300 truncate max-w-xs transition-colors shrink-0"
              >
                {hist}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Results Section */}
      <div className="space-y-4">
        {results.length > 0 && (
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
            Search Results ({results.length})
          </h3>
        )}

        {results.map((res, idx) => (
          <div
            key={idx}
            className="p-5 rounded-2xl bg-slate-900/50 border border-purple-900/30 hover:border-cyan-500/30 backdrop-blur-xl space-y-3 transition-all"
          >
            <div className="flex items-start justify-between gap-3">
              <div className="space-y-1">
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-950 text-cyan-300 border border-cyan-800/40">
                  {res.source}
                </span>
                <h4 className="text-base font-bold text-white hover:text-cyan-300 cursor-pointer">
                  <a href={res.url} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1.5">
                    <span>{res.title}</span>
                    <ExternalLink className="w-3.5 h-3.5 text-slate-400" />
                  </a>
                </h4>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">{res.snippet}</p>

            {/* AI Summary Output if requested */}
            {summaries[idx] && (
              <div className="p-3 rounded-xl bg-purple-950/40 border border-purple-800/40 text-xs text-purple-200 space-y-1">
                <span className="font-semibold text-pink-400 flex items-center gap-1">
                  <Sparkles className="w-3 h-3" /> {assistantName} Summary:
                </span>
                <p>{summaries[idx]}</p>
              </div>
            )}

            {/* Action Buttons on Result */}
            <div className="flex items-center gap-3 pt-1">
              <button
                onClick={() => handleSummarize(idx, res)}
                disabled={summarizingIdx === idx}
                className="text-xs font-medium text-pink-400 hover:text-pink-300 flex items-center gap-1 transition-colors"
              >
                <BookOpen className="w-3.5 h-3.5" />
                <span>{summarizingIdx === idx ? 'Summarizing...' : 'Summarize with AI'}</span>
              </button>

              <button
                onClick={() => handleAskInChat(res)}
                className="text-xs font-medium text-cyan-400 hover:text-cyan-300 flex items-center gap-1 transition-colors"
              >
                <span>Ask {assistantName} about this</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
