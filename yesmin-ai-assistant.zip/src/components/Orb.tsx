import React from 'react';
import { AssistantStatus, useApp } from '../context/AppContext';

interface OrbProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  status?: AssistantStatus;
  onClick?: () => void;
  showStatusLabel?: boolean;
}

export const Orb: React.FC<OrbProps> = ({
  size = 'md',
  status = 'idle',
  onClick,
  showStatusLabel = true,
}) => {
  const { settings } = useApp();

  const sizeClasses = {
    sm: 'w-16 h-16',
    md: 'w-28 h-28 sm:w-36 sm:h-36',
    lg: 'w-44 h-44 sm:w-56 sm:h-56',
    xl: 'w-60 h-60 sm:w-72 sm:h-72',
  }[size];

  // Accent-specific colors
  const accentGlow = {
    pink: 'from-pink-500/80 via-purple-600/70 to-indigo-700/80 shadow-pink-500/50',
    purple: 'from-purple-500/80 via-violet-600/70 to-indigo-800/80 shadow-purple-500/50',
    cyan: 'from-cyan-400/80 via-blue-600/70 to-purple-700/80 shadow-cyan-500/50',
    emerald: 'from-emerald-400/80 via-teal-600/70 to-blue-700/80 shadow-emerald-500/50',
    amber: 'from-amber-400/80 via-orange-600/70 to-purple-800/80 shadow-amber-500/50',
  }[settings.accentColor || 'pink'];

  const ringColor = {
    pink: 'border-pink-500/30',
    purple: 'border-purple-500/30',
    cyan: 'border-cyan-500/30',
    emerald: 'border-emerald-500/30',
    amber: 'border-amber-500/30',
  }[settings.accentColor || 'pink'];

  const statusLabels: Record<AssistantStatus, { text: string; color: string }> = {
    idle: { text: 'Online • Ready', color: 'text-purple-300' },
    listening: { text: 'Listening...', color: 'text-pink-400 animate-pulse' },
    thinking: { text: 'Processing...', color: 'text-cyan-400 animate-pulse' },
    speaking: { text: 'Speaking...', color: 'text-emerald-400' },
  };

  return (
    <div className="flex flex-col items-center justify-center select-none">
      <div
        onClick={onClick}
        className={`relative ${sizeClasses} flex items-center justify-center cursor-pointer transition-transform duration-300 active:scale-95`}
      >
        {/* Outer orbital halo ring 1 */}
        <div
          className={`absolute inset-[-14px] rounded-full border ${ringColor} ${
            status === 'speaking'
              ? 'animate-ping opacity-60'
              : status === 'listening'
              ? 'animate-pulse opacity-80'
              : 'opacity-40 animate-spin-slow'
          }`}
        />

        {/* Outer orbital halo ring 2 */}
        <div
          className={`absolute inset-[-6px] rounded-full border border-dashed ${ringColor} opacity-50 ${
            status === 'thinking' ? 'animate-spin' : ''
          }`}
          style={{ animationDuration: status === 'thinking' ? '3s' : '15s' }}
        />

        {/* Core Glowing Orb */}
        <div
          className={`w-full h-full rounded-full bg-gradient-to-tr ${accentGlow} shadow-2xl backdrop-blur-2xl flex items-center justify-center overflow-hidden transition-all duration-500 ${
            status === 'speaking'
              ? 'scale-105 shadow-[0_0_50px_rgba(236,72,153,0.8)]'
              : status === 'listening'
              ? 'scale-110 shadow-[0_0_60px_rgba(244,114,182,0.9)]'
              : 'hover:scale-105 shadow-[0_0_35px_rgba(168,85,247,0.5)]'
          }`}
        >
          {/* Inner plasma effect */}
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-white/30 via-transparent to-black/40 mix-blend-overlay" />

          {/* Core light pulse */}
          <div
            className={`w-1/2 h-1/2 rounded-full bg-white/40 blur-md ${
              status !== 'idle' ? 'animate-pulse' : ''
            }`}
          />

          {/* Sound wave visual bars inside orb if speaking or listening */}
          {(status === 'speaking' || status === 'listening') && (
            <div className="absolute inset-0 flex items-center justify-center gap-1 opacity-80">
              <span className="w-1 h-8 bg-white rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
              <span className="w-1 h-12 bg-white rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
              <span className="w-1 h-6 bg-white rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
              <span className="w-1 h-10 bg-white rounded-full animate-bounce" style={{ animationDelay: '450ms' }} />
              <span className="w-1 h-4 bg-white rounded-full animate-bounce" style={{ animationDelay: '600ms' }} />
            </div>
          )}
        </div>
      </div>

      {showStatusLabel && (
        <div className="mt-3 text-center">
          <span className={`text-xs font-medium tracking-wide uppercase px-2.5 py-0.5 rounded-full bg-black/40 backdrop-blur-md border border-white/10 ${statusLabels[status].color}`}>
            {statusLabels[status].text}
          </span>
        </div>
      )}
    </div>
  );
};
