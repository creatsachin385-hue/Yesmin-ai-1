import React, { useState, useRef } from 'react';
import { useApp } from '../context/AppContext';
import { SUPPORTED_APPS, safeCalculate } from '../utils/tools';
import { DeviceBridge } from '../utils/androidBridge';
import {
  Zap,
  ExternalLink,
  Camera,
  Calculator,
  Smartphone,
  Shield,
  Download,
  CheckCircle2,
  X,
  Play,
} from 'lucide-react';

export const AppsActionsView: React.FC = () => {
  const { showToast, triggerNotification } = useApp();

  const [activeCamera, setActiveCamera] = useState(false);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [calcInput, setCalcInput] = useState('15 * 24 + 100');
  const [calcResult, setCalcResult] = useState<string | number | null>(460);
  const [showBridgeModal, setShowBridgeModal] = useState(false);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const isAndroidWebView = DeviceBridge.isAndroidWebView();

  const handleLaunchApp = (app: (typeof SUPPORTED_APPS)[0]) => {
    if (app.action === 'internal_camera') {
      openCameraModal();
      return;
    }

    if (app.action === 'internal_calc') {
      const calcSection = document.getElementById('calc-section');
      calcSection?.scrollIntoView({ behavior: 'smooth' });
      return;
    }

    const result = DeviceBridge.executeAction('OPEN_APP', {
      url: app.url,
      package: app.package,
    });

    showToast(result.details, 'success');
  };

  // Camera Handler
  const openCameraModal = async () => {
    setActiveCamera(true);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'user' },
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (err: any) {
      showToast('Camera permission denied or camera unavailable', 'warning');
      closeCameraModal();
    }
  };

  const closeCameraModal = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    setActiveCamera(false);
  };

  const takeSnapshot = () => {
    if (!videoRef.current) return;
    const canvas = document.createElement('canvas');
    canvas.width = videoRef.current.videoWidth || 640;
    canvas.height = videoRef.current.videoHeight || 480;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
      const dataUrl = canvas.toDataURL('image/png');
      setCapturedImage(dataUrl);
      showToast('Camera snapshot captured', 'success');
    }
  };

  const handleCalculate = () => {
    const res = safeCalculate(calcInput);
    if (res.success && res.result !== undefined) {
      setCalcResult(res.result);
      showToast(`Result: ${res.result}`, 'info');
    } else {
      setCalcResult(`Error: ${res.error}`);
      showToast(res.error || 'Calculation error', 'error');
    }
  };

  const downloadAndroidCode = () => {
    const kotlinCode = `// Android Kotlin Companion Bridge
package com.yesmin.ai.assistant

import android.webkit.JavascriptInterface
import android.content.Context
import android.content.Intent
import android.net.Uri

class AndroidActionManager(private val context: Context) {

    @JavascriptInterface
    fun postMessage(jsonString: String) {
        // Parse Action
        // e.g. OPEN_APP, MAKE_CALL, SEND_NOTIFICATION
    }

    @JavascriptInterface
    fun openApp(packageName: String, uriString: String?): Boolean {
        return try {
            val intent = context.packageManager.getLaunchIntentForPackage(packageName)
            if (intent != null) {
                context.startActivity(intent)
                true
            } else {
                false
            }
        } catch (e: Exception) {
            false
        }
    }
}`;

    const blob = new Blob([kotlinCode], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'AndroidActionManager.kt';
    a.click();
    showToast('Downloaded AndroidActionManager.kt', 'success');
  };

  return (
    <div className="flex-1 overflow-y-auto px-4 py-6 sm:px-8 max-w-5xl mx-auto space-y-8 pb-24 md:pb-12">
      {/* Title & Android Bridge Status */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-5 rounded-3xl bg-slate-900/60 border border-purple-900/40 backdrop-blur-xl">
        <div className="space-y-1">
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Zap className="w-5 h-5 text-pink-400" />
            Apps & Actions Hub
          </h2>
          <p className="text-xs text-slate-400">
            Automated shortcuts, live device camera, calculation engine & Android companion bridge.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowBridgeModal(true)}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-purple-950/60 hover:bg-purple-900/80 border border-purple-800/40 text-purple-200 text-xs font-semibold transition-all"
          >
            <Smartphone className="w-4 h-4 text-pink-400" />
            <span>Android Bridge Arch</span>
          </button>

          <button
            onClick={() => triggerNotification('Yesmin Jarvis Alert', 'All automated subsystems running optimally.')}
            className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs text-slate-200 font-medium transition-all"
          >
            Test Notification
          </button>
        </div>
      </div>

      {/* Apps Grid */}
      <section className="space-y-4">
        <h3 className="text-sm font-bold text-white uppercase tracking-wider">
          Quick Launch Apps
        </h3>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3.5">
          {SUPPORTED_APPS.map((app) => (
            <button
              key={app.id}
              onClick={() => handleLaunchApp(app)}
              className="p-4 rounded-2xl border border-purple-900/30 bg-slate-900/50 hover:bg-slate-900/90 hover:border-pink-500/40 backdrop-blur-xl text-left flex flex-col justify-between h-28 group transition-all duration-200 hover:scale-[1.03] active:scale-95 shadow-lg"
            >
              <div className="flex items-center justify-between">
                <div
                  className="w-10 h-10 rounded-xl flex items-center justify-center shadow-inner"
                  style={{ backgroundColor: `${app.color}20`, color: app.color }}
                >
                  <ExternalLink className="w-5 h-5" />
                </div>
                <span className="text-[10px] text-slate-500 uppercase font-mono">
                  {app.package ? 'Native' : 'Web'}
                </span>
              </div>

              <div>
                <h4 className="text-sm font-bold text-white group-hover:text-pink-300 transition-colors">
                  {app.name}
                </h4>
                <p className="text-[11px] text-slate-400">Launch shortcut</p>
              </div>
            </button>
          ))}
        </div>
      </section>

      {/* Internal Tools Section: Calculator */}
      <section id="calc-section" className="space-y-4">
        <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
          <Calculator className="w-4 h-4 text-amber-400" />
          Safe Calculator Engine
        </h3>

        <div className="p-5 rounded-3xl bg-slate-900/50 border border-purple-900/30 backdrop-blur-xl max-w-xl space-y-4">
          <div className="flex gap-2">
            <input
              type="text"
              value={calcInput}
              onChange={(e) => setCalcInput(e.target.value)}
              placeholder="e.g. 250 * 1.18 + 50"
              className="flex-1 px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white font-mono text-sm focus:outline-none focus:border-amber-500"
            />
            <button
              onClick={handleCalculate}
              className="px-5 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs shadow-md transition-all"
            >
              Calculate
            </button>
          </div>

          {calcResult !== null && (
            <div className="p-3 rounded-xl bg-black/40 border border-amber-500/30 font-mono text-xs flex justify-between items-center">
              <span className="text-slate-400">Result:</span>
              <span className="text-amber-400 font-bold text-sm">{calcResult}</span>
            </div>
          )}
        </div>
      </section>

      {/* Live Camera Modal */}
      {activeCamera && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="w-full max-w-md rounded-3xl bg-slate-900 border border-purple-800/60 p-5 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Camera className="w-4 h-4 text-pink-400" />
                Live Camera Feed
              </h3>
              <button onClick={closeCameraModal} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="relative aspect-video rounded-2xl overflow-hidden bg-black border border-slate-800">
              <video ref={videoRef} autoPlay playsInline muted className="w-full h-full object-cover" />
            </div>

            <div className="flex items-center justify-between">
              <button
                onClick={takeSnapshot}
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 text-white text-xs font-semibold shadow-md transition-all"
              >
                Capture Snapshot
              </button>

              <button
                onClick={closeCameraModal}
                className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold"
              >
                Close
              </button>
            </div>

            {capturedImage && (
              <div className="p-2 rounded-xl bg-slate-950 border border-purple-800/40 space-y-2">
                <p className="text-[11px] text-slate-400">Snapshot Preview:</p>
                <img src={capturedImage} alt="Capture" className="w-full rounded-lg" />
              </div>
            )}
          </div>
        </div>
      )}

      {/* Android Bridge Architecture Info Modal */}
      {showBridgeModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="w-full max-w-lg rounded-3xl bg-slate-900 border border-purple-800/60 p-6 space-y-4 shadow-2xl max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Smartphone className="w-5 h-5 text-pink-400" />
                Android WebView & Companion Bridge
              </h3>
              <button onClick={() => setShowBridgeModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="text-xs text-slate-300 space-y-3 leading-relaxed">
              <p>
                Standard browsers operate in sandboxes and cannot execute native OS commands directly. To enable direct native app controls, this application implements an extensible 3-tier architecture:
              </p>

              <div className="p-3 rounded-2xl bg-black/50 border border-purple-900/40 font-mono text-[11px] space-y-1 text-pink-300">
                <p>1. Web App UI (window.AndroidBridge / Intent dispatch)</p>
                <p className="text-purple-400">   ↓ JSON message passing via @JavascriptInterface</p>
                <p>2. Android WebView Container (AndroidActionManager)</p>
                <p className="text-purple-400">   ↓ Package Manager & Intent resolution</p>
                <p className="text-emerald-400">3. Native Android OS Actions (WhatsApp, Camera, Calls, etc.)</p>
              </div>

              <div className="space-y-1">
                <h4 className="font-semibold text-white">Current Environment:</h4>
                <p className="text-slate-400">
                  {isAndroidWebView
                    ? 'Connected inside Android WebView container with window.AndroidBridge available.'
                    : 'Running in standard web browser. Native actions fall back safely to Android Web Intents & URL handlers.'}
                </p>
              </div>
            </div>

            <div className="flex justify-between items-center pt-2">
              <button
                onClick={downloadAndroidCode}
                className="flex items-center gap-2 px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold shadow-md transition-all"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export Kotlin Code</span>
              </button>

              <button
                onClick={() => setShowBridgeModal(false)}
                className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-medium"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
