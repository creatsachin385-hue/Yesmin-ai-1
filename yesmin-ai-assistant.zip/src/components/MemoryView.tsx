import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { api } from '../services/api';
import { MemoryItem } from '../types';
import { searchMemories } from '../utils/memory';
import { getEffectiveAssistantName } from '../utils/personality';
import {
  Brain,
  Plus,
  Search,
  Trash2,
  Edit2,
  Check,
  ToggleLeft,
  ToggleRight,
  Sparkles,
  Filter,
} from 'lucide-react';

export const MemoryView: React.FC = () => {
  const { settings, updateSettings, showToast } = useApp();
  const assistantName = getEffectiveAssistantName(settings.assistantName);

  const [memories, setMemories] = useState<MemoryItem[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [isAdding, setIsAdding] = useState(false);
  const [newKey, setNewKey] = useState('');
  const [newValue, setNewValue] = useState('');
  const [newCategory, setNewCategory] = useState<MemoryItem['category']>('preference');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editValue, setEditValue] = useState('');

  useEffect(() => {
    loadMemories();
  }, []);

  const loadMemories = async () => {
    try {
      const list = await api.getMemories();
      setMemories(list);
    } catch (err: any) {
      showToast(err.message || 'Error loading memories', 'error');
    }
  };

  const handleCreateMemory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newKey.trim() || !newValue.trim()) return;

    try {
      const created = await api.createMemory(newKey.trim(), newValue.trim(), newCategory);
      setMemories((prev) => [created, ...prev]);
      setNewKey('');
      setNewValue('');
      setIsAdding(false);
      showToast('Memory saved to database', 'success');
    } catch (err: any) {
      showToast(err.message || 'Failed to save memory', 'error');
    }
  };

  const handleUpdate = async (id: string) => {
    if (!editValue.trim()) return;
    try {
      const updated = await api.updateMemory(id, { value: editValue.trim() });
      setMemories((prev) => prev.map((m) => (m.id === id ? updated : m)));
      setEditingId(null);
      showToast('Memory updated', 'success');
    } catch (err: any) {
      showToast('Failed to update memory', 'error');
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await api.deleteMemory(id);
      setMemories((prev) => prev.filter((m) => m.id !== id));
      showToast('Memory deleted', 'info');
    } catch (err: any) {
      showToast('Failed to delete memory', 'error');
    }
  };

  const handleClearAll = async () => {
    if (!window.confirm('Are you sure you want to delete all saved memories?')) return;
    try {
      await api.clearMemories();
      setMemories([]);
      showToast('All memories cleared', 'info');
    } catch (err: any) {
      showToast('Failed to clear memories', 'error');
    }
  };

  const toggleMemoryEngine = () => {
    updateSettings({ memoryEnabled: !settings.memoryEnabled });
  };

  // Filter memories
  const filtered = searchMemories(memories, searchQuery).filter(
    (m) => selectedCategory === 'all' || m.category === selectedCategory
  );

  return (
    <div className="flex-1 overflow-y-auto px-4 py-6 sm:px-8 max-w-5xl mx-auto space-y-6 pb-24 md:pb-12">
      {/* Top Banner: Status & Toggle */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-6 rounded-3xl bg-slate-900/60 border border-purple-900/40 backdrop-blur-xl">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <Brain className="w-5 h-5 text-purple-400" />
              Persistent Memory Core
            </h2>
            <span
              className={`text-[10px] font-semibold px-2 py-0.5 rounded-full border ${
                settings.memoryEnabled
                  ? 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30'
                  : 'bg-slate-800 text-slate-400 border-slate-700'
              }`}
            >
              {settings.memoryEnabled ? 'Active' : 'Disabled'}
            </span>
          </div>
          <p className="text-xs text-slate-400">
            {assistantName} uses stored preferences, nicknames, and conversation facts naturally in every turn.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={toggleMemoryEngine}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl border text-xs font-semibold transition-all ${
              settings.memoryEnabled
                ? 'bg-purple-900/40 border-purple-500/50 text-pink-300'
                : 'bg-slate-900 border-slate-800 text-slate-400'
            }`}
          >
            {settings.memoryEnabled ? (
              <ToggleRight className="w-5 h-5 text-pink-400" />
            ) : (
              <ToggleLeft className="w-5 h-5 text-slate-500" />
            )}
            <span>{settings.memoryEnabled ? 'Memory Enabled' : 'Memory Disabled'}</span>
          </button>

          <button
            onClick={() => setIsAdding(!isAdding)}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 text-white text-xs font-semibold shadow-md active:scale-95 transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>Add Memory</span>
          </button>
        </div>
      </div>

      {/* Add Memory Form if active */}
      {isAdding && (
        <form
          onSubmit={handleCreateMemory}
          className="p-5 rounded-3xl bg-slate-900/80 border border-pink-500/40 backdrop-blur-xl space-y-4 shadow-xl"
        >
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-pink-400" />
            Store New Memory
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <input
              type="text"
              placeholder="Memory Key (e.g. Favorite Food, Coding Style)"
              value={newKey}
              onChange={(e) => setNewKey(e.target.value)}
              className="px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white focus:outline-none focus:border-pink-500"
            />

            <input
              type="text"
              placeholder="Value / Detail to remember"
              value={newValue}
              onChange={(e) => setNewValue(e.target.value)}
              className="px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white focus:outline-none focus:border-pink-500"
            />

            <select
              value={newCategory}
              onChange={(e) => setNewCategory(e.target.value as any)}
              className="px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white focus:outline-none focus:border-pink-500"
            >
              <option value="preference">Preference</option>
              <option value="companion">Companion / Romantic</option>
              <option value="personal">Personal Detail</option>
              <option value="work">Project / Work</option>
              <option value="instruction">User Instruction</option>
            </select>
          </div>

          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setIsAdding(false)}
              className="px-3 py-1.5 text-xs text-slate-400 hover:text-white"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 text-xs rounded-xl bg-pink-600 text-white font-semibold shadow"
            >
              Save Memory
            </button>
          </div>
        </form>
      )}

      {/* Search & Category Filter Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
          <input
            type="text"
            placeholder="Search memories by keyword..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-2 text-xs rounded-2xl bg-slate-900/80 border border-slate-800 text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
          />
        </div>

        <div className="flex items-center gap-2 overflow-x-auto">
          {['all', 'preference', 'companion', 'personal', 'work', 'instruction'].map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-xl text-xs capitalize transition-all shrink-0 ${
                selectedCategory === cat
                  ? 'bg-purple-600 text-white font-semibold'
                  : 'bg-slate-900/60 text-slate-400 hover:text-slate-200'
              }`}
            >
              {cat}
            </button>
          ))}

          {memories.length > 0 && (
            <button
              onClick={handleClearAll}
              className="px-3 py-1.5 rounded-xl text-xs text-red-400 hover:bg-red-950/40 border border-red-500/20 transition-colors shrink-0"
            >
              Clear All
            </button>
          )}
        </div>
      </div>

      {/* Memories List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filtered.length === 0 ? (
          <div className="col-span-full p-8 rounded-3xl bg-slate-900/40 border border-purple-900/20 text-center text-xs text-slate-500">
            No memories found matching your criteria.
          </div>
        ) : (
          filtered.map((item) => (
            <div
              key={item.id}
              className="p-4 rounded-2xl bg-slate-900/60 border border-purple-900/30 hover:border-purple-500/30 backdrop-blur-xl space-y-2 group transition-all"
            >
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded-full bg-purple-950 text-purple-300 border border-purple-800/40">
                  {item.category}
                </span>

                <div className="flex items-center gap-1 opacity-80 group-hover:opacity-100 transition-opacity">
                  {editingId !== item.id && (
                    <button
                      onClick={() => {
                        setEditingId(item.id);
                        setEditValue(item.value);
                      }}
                      className="p-1 hover:text-pink-400 text-slate-400"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                  <button
                    onClick={() => handleDelete(item.id)}
                    className="p-1 hover:text-red-400 text-slate-400"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              <div>
                <h4 className="text-xs font-bold text-white">{item.key}</h4>
                {editingId === item.id ? (
                  <div className="flex gap-2 mt-2">
                    <input
                      type="text"
                      value={editValue}
                      onChange={(e) => setEditValue(e.target.value)}
                      className="flex-1 px-2 py-1 text-xs rounded bg-slate-950 border border-pink-500 text-white"
                    />
                    <button
                      onClick={() => handleUpdate(item.id)}
                      className="p-1 rounded bg-pink-600 text-white"
                    >
                      <Check className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ) : (
                  <p className="text-xs text-slate-300 mt-0.5">{item.value}</p>
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
