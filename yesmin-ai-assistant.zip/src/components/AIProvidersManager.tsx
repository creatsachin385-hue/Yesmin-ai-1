import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { api } from '../services/api';
import { AIProviderId, ProviderConfig } from '../types';
import {
  Cpu,
  Key,
  CheckCircle2,
  AlertCircle,
  ExternalLink,
  Zap,
  Globe,
  Lock,
  Eye,
  EyeOff,
  Server,
  RefreshCw,
  Sparkles,
  ShieldCheck,
  Radio,
} from 'lucide-react';

interface ProviderDefinition {
  id: AIProviderId;
  name: string;
  badge: string;
  tagline: string;
  websiteUrl: string;
  keyPrefixHint: string;
  defaultBaseUrl?: string;
  defaultModel: string;
  modelOptions: string[];
  description: string;
}

const PROVIDERS_CATALOG: ProviderDefinition[] = [
  {
    id: 'gemini',
    name: 'Google Gemini',
    badge: 'Core Engine',
    tagline: 'Google AI Studio / Makersuite',
    websiteUrl: 'https://aistudio.google.com/app/apikey',
    keyPrefixHint: 'AIzaSy...',
    defaultModel: 'gemini-3.8-flash',
    modelOptions: [
      'gemini-3.8-flash',
      'gemini-3.1-flash-lite',
      'gemini-4-argon',
      'gemini-2.5-flash',
      'gemini-2.5-pro',
    ],
    description: 'High-speed multimodal intelligence with native audio streaming and vision.',
  },
  {
    id: 'openai',
    name: 'OpenAI (ChatGPT)',
    badge: 'Industry Standard',
    tagline: 'platform.openai.com',
    websiteUrl: 'https://platform.openai.com/api-keys',
    keyPrefixHint: 'sk-proj-... or sk-...',
    defaultBaseUrl: 'https://api.openai.com/v1',
    defaultModel: 'gpt-4o-mini',
    modelOptions: ['gpt-4o-mini', 'gpt-4o', 'o1', 'o3-mini', 'gpt-3.5-turbo'],
    description: 'Official OpenAI GPT models for smart conversations and coding.',
  },
  {
    id: 'anthropic',
    name: 'Anthropic Claude',
    badge: 'Reasoning & Coding',
    tagline: 'console.anthropic.com',
    websiteUrl: 'https://console.anthropic.com/settings/keys',
    keyPrefixHint: 'sk-ant-api03-...',
    defaultModel: 'claude-3-5-sonnet-20241022',
    modelOptions: [
      'claude-3-5-sonnet-20241022',
      'claude-3-5-haiku-20241022',
      'claude-3-7-sonnet-20250219',
      'claude-3-opus-20240229',
    ],
    description: 'Claude 3.5 Sonnet & Haiku with nuanced writing and high-integrity reasoning.',
  },
  {
    id: 'groq',
    name: 'Groq Cloud',
    badge: 'Ultra Fast (500 tps)',
    tagline: 'console.groq.com',
    websiteUrl: 'https://console.groq.com/keys',
    keyPrefixHint: 'gsk_...',
    defaultBaseUrl: 'https://api.groq.com/openai/v1',
    defaultModel: 'llama-3.3-70b-versatile',
    modelOptions: [
      'llama-3.3-70b-versatile',
      'llama-3.1-8b-instant',
      'deepseek-r1-distill-llama-70b',
      'mixtral-8x7b-32768',
    ],
    description: 'Lightning-speed LPU inference with instantaneous responses in under 200ms.',
  },
  {
    id: 'deepseek',
    name: 'DeepSeek AI',
    badge: 'Deep Reasoning',
    tagline: 'platform.deepseek.com',
    websiteUrl: 'https://platform.deepseek.com/api_keys',
    keyPrefixHint: 'sk-...',
    defaultBaseUrl: 'https://api.deepseek.com',
    defaultModel: 'deepseek-chat',
    modelOptions: ['deepseek-chat', 'deepseek-reasoner'],
    description: 'State-of-the-art DeepSeek-V3 and DeepSeek-R1 reasoning models at fraction of cost.',
  },
  {
    id: 'openrouter',
    name: 'OpenRouter',
    badge: '100+ Models in 1 Key',
    tagline: 'openrouter.ai',
    websiteUrl: 'https://openrouter.ai/keys',
    keyPrefixHint: 'sk-or-v1-...',
    defaultBaseUrl: 'https://openrouter.ai/api/v1',
    defaultModel: 'deepseek/deepseek-r1:free',
    modelOptions: [
      'deepseek/deepseek-r1:free',
      'meta-llama/llama-3.3-70b-instruct',
      'anthropic/claude-3.5-sonnet',
      'google/gemini-2.0-flash-exp:free',
      'mistralai/mistral-large-2411',
    ],
    description: 'Universal gateway to over 100 open and closed models including free-tier models.',
  },
  {
    id: 'mistral',
    name: 'Mistral AI',
    badge: 'European Frontier AI',
    tagline: 'console.mistral.ai',
    websiteUrl: 'https://console.mistral.ai/api-keys/',
    keyPrefixHint: 'Bearer token',
    defaultBaseUrl: 'https://api.mistral.ai/v1',
    defaultModel: 'mistral-small-latest',
    modelOptions: ['mistral-small-latest', 'mistral-large-latest', 'codestral-latest'],
    description: 'Fast, efficient European frontier models and Codestral coding engine.',
  },
  {
    id: 'together',
    name: 'Together AI',
    badge: 'Open Source Cluster',
    tagline: 'api.together.ai',
    websiteUrl: 'https://api.together.xyz/settings/api-keys',
    keyPrefixHint: 'Together API key',
    defaultBaseUrl: 'https://api.together.xyz/v1',
    defaultModel: 'meta-llama/Llama-3.3-70B-Instruct-Turbo',
    modelOptions: [
      'meta-llama/Llama-3.3-70B-Instruct-Turbo',
      'deepseek-ai/DeepSeek-R1',
      'Qwen/Qwen2.5-72B-Instruct-Turbo',
    ],
    description: 'High performance dedicated endpoints for open weights architectures.',
  },
  {
    id: 'custom',
    name: '🌐 Custom Website / Local Endpoint',
    badge: 'Any URL & Website',
    tagline: 'Ollama, LM Studio, Perplexity, vLLM, Any Provider',
    websiteUrl: 'https://github.com/ollama/ollama',
    keyPrefixHint: 'API Key (Optional for local)',
    defaultBaseUrl: 'http://localhost:11434/v1',
    defaultModel: 'llama3',
    modelOptions: ['llama3', 'mistral', 'custom-model'],
    description: 'Connect ANY OpenAI-compatible website, API service, or local network AI server.',
  },
];

export const AIProvidersManager: React.FC = () => {
  const { settings, updateSettings, showToast } = useApp();

  const [selectedProviderId, setSelectedProviderId] = useState<AIProviderId>(
    settings.activeProvider || 'gemini'
  );

  // Stored configs in state
  const providerConfigs = settings.providerConfigs || {};

  const currentDef =
    PROVIDERS_CATALOG.find((p) => p.id === selectedProviderId) || PROVIDERS_CATALOG[0];
  const currentConfig: ProviderConfig = providerConfigs[selectedProviderId] || {
    id: selectedProviderId,
    name: currentDef.name,
    enabled: true,
    apiKey: '',
    baseUrl: currentDef.defaultBaseUrl || '',
    model: currentDef.defaultModel,
    status: 'disconnected',
  };

  const [apiKeyInput, setApiKeyInput] = useState<string>(currentConfig.apiKey || '');
  const [baseUrlInput, setBaseUrlInput] = useState<string>(
    currentConfig.baseUrl || currentDef.defaultBaseUrl || ''
  );
  const [modelInput, setModelInput] = useState<string>(
    currentConfig.model || currentDef.defaultModel
  );
  const [customHeadersInput, setCustomHeadersInput] = useState<string>(
    currentConfig.customHeaders || ''
  );

  const [showKeyPassword, setShowKeyPassword] = useState<boolean>(false);
  const [isTesting, setIsTesting] = useState<boolean>(false);
  const [testResult, setTestResult] = useState<{
    success?: boolean;
    latencyMs?: number;
    response?: string;
    model?: string;
    message?: string;
    error?: string;
    testedAt?: string;
  } | null>(null);

  // When selected provider changes, refresh local input state
  const handleSelectProvider = (id: AIProviderId) => {
    setSelectedProviderId(id);
    const def = PROVIDERS_CATALOG.find((p) => p.id === id) || PROVIDERS_CATALOG[0];
    const cfg = providerConfigs[id] || {
      id,
      name: def.name,
      enabled: true,
      apiKey: '',
      baseUrl: def.defaultBaseUrl || '',
      model: def.defaultModel,
      status: 'disconnected',
    };
    setApiKeyInput(cfg.apiKey || '');
    setBaseUrlInput(cfg.baseUrl || def.defaultBaseUrl || '');
    setModelInput(cfg.model || def.defaultModel);
    setCustomHeadersInput(cfg.customHeaders || '');
    setTestResult(null);
  };

  // Save current provider settings
  const handleSaveProviderConfig = async (activateImmediately: boolean = false) => {
    const updatedConfig: ProviderConfig = {
      ...currentConfig,
      id: selectedProviderId,
      name: currentDef.name,
      apiKey: apiKeyInput.trim(),
      baseUrl: baseUrlInput.trim() || currentDef.defaultBaseUrl,
      model: modelInput.trim() || currentDef.defaultModel,
      customHeaders: customHeadersInput.trim(),
      status: currentConfig.status || 'disconnected',
    };

    const newConfigs = {
      ...providerConfigs,
      [selectedProviderId]: updatedConfig,
    };

    const updatePayload: any = {
      providerConfigs: newConfigs,
    };

    if (activateImmediately || settings.activeProvider === selectedProviderId) {
      updatePayload.activeProvider = selectedProviderId;
      if (selectedProviderId === 'gemini') {
        updatePayload.geminiModel = modelInput.trim() || 'gemini-3.8-flash';
      }
    }

    await updateSettings(updatePayload);
    showToast(
      activateImmediately
        ? `Saved and set ${currentDef.name} as active AI engine!`
        : `Configuration for ${currentDef.name} saved!`,
      'success'
    );
  };

  // Test provider connection in real-time
  const handleTestConnection = async () => {
    if (!apiKeyInput.trim() && selectedProviderId !== 'custom') {
      showToast('Please enter an API Key first to test connection.', 'warning');
      return;
    }

    setIsTesting(true);
    setTestResult(null);

    try {
      const result = await api.testProvider({
        provider: selectedProviderId,
        apiKey: apiKeyInput.trim(),
        model: modelInput.trim() || currentDef.defaultModel,
        baseUrl: baseUrlInput.trim() || currentDef.defaultBaseUrl,
        customHeaders: customHeadersInput.trim(),
      });

      const latencyMs = result.latencyMs || 0;
      const resData = {
        success: result.success,
        latencyMs,
        response: result.response,
        model: result.model || modelInput,
        message: result.message,
        error: result.error,
        testedAt: new Date().toLocaleTimeString(),
      };

      setTestResult(resData);

      // Save status back to provider config
      const updatedConfig: ProviderConfig = {
        ...currentConfig,
        id: selectedProviderId,
        apiKey: apiKeyInput.trim(),
        baseUrl: baseUrlInput.trim() || currentDef.defaultBaseUrl,
        model: modelInput.trim() || currentDef.defaultModel,
        status: result.success ? 'connected' : 'error',
        latencyMs,
        lastTested: new Date().toISOString(),
        testedModel: result.model || modelInput,
        error: result.error,
      };

      await updateSettings({
        providerConfigs: {
          ...providerConfigs,
          [selectedProviderId]: updatedConfig,
        },
      });

      if (result.success) {
        showToast(`⚡ ${currentDef.name} is working perfectly (${latencyMs}ms)!`, 'success');
      } else {
        showToast(`❌ ${currentDef.name} test failed: ${result.error}`, 'error');
      }
    } catch (err: any) {
      setTestResult({
        success: false,
        error: err.message || 'Network connection failed',
        testedAt: new Date().toLocaleTimeString(),
      });
      showToast(err.message || 'Connection test failed', 'error');
    } finally {
      setIsTesting(false);
    }
  };

  const isActive = settings.activeProvider === selectedProviderId;

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="p-5 rounded-3xl bg-gradient-to-r from-purple-950/40 via-slate-900 to-pink-950/40 border border-purple-800/40 shadow-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-pink-500 to-purple-600 flex items-center justify-center text-white shadow-lg shadow-pink-500/30">
            <Cpu className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base sm:text-lg font-bold text-white tracking-wide">
                Universal AI Provider &amp; API Key Manager
              </h3>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-medium">
                Live Ping Tester
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Add API keys from ANY website (Google, OpenAI, Claude, Groq, DeepSeek, OpenRouter, Mistral, Together, or Custom). Test latency &amp; check if keys are working in real-time.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400">Active Engine:</span>
          <span className="px-3 py-1 rounded-full bg-pink-500/20 border border-pink-500/40 text-pink-300 font-bold text-xs">
            {PROVIDERS_CATALOG.find((p) => p.id === settings.activeProvider)?.name ||
              settings.activeProvider}
          </span>
        </div>
      </div>

      {/* Provider Selector Cards Grid */}
      <div className="space-y-2">
        <label className="text-xs font-bold uppercase tracking-wider text-slate-400">
          Select AI Provider or Custom Website:
        </label>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2.5">
          {PROVIDERS_CATALOG.map((p) => {
            const isSelected = selectedProviderId === p.id;
            const isCurrentActive = settings.activeProvider === p.id;
            const hasKey = !!providerConfigs[p.id]?.apiKey;
            const cfg = providerConfigs[p.id];
            const isConnected = cfg?.status === 'connected';

            return (
              <button
                key={p.id}
                onClick={() => handleSelectProvider(p.id)}
                className={`p-3 rounded-2xl border text-left flex flex-col justify-between transition-all relative overflow-hidden group ${
                  isSelected
                    ? 'bg-purple-900/30 border-pink-500 text-white shadow-lg shadow-pink-500/10'
                    : 'bg-slate-950/70 border-slate-800/80 text-slate-400 hover:bg-slate-900 hover:text-white'
                }`}
              >
                {/* Active in chat badge */}
                {isCurrentActive && (
                  <span className="absolute top-2 right-2 flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                  </span>
                )}

                <div className="space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-white group-hover:text-pink-300 transition-colors">
                      {p.name.replace('🌐 ', '')}
                    </span>
                  </div>
                  <span className="text-[10px] text-pink-400/90 font-medium block">
                    {p.badge}
                  </span>
                </div>

                <div className="pt-2 flex items-center justify-between text-[10px]">
                  {isConnected ? (
                    <span className="text-emerald-400 flex items-center gap-1 font-mono">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                      {cfg.latencyMs ? `${cfg.latencyMs}ms` : 'Ready'}
                    </span>
                  ) : hasKey ? (
                    <span className="text-amber-400">Configured</span>
                  ) : (
                    <span className="text-slate-500">Not setup</span>
                  )}
                  {isCurrentActive && (
                    <span className="text-emerald-400 font-bold uppercase text-[9px]">Active</span>
                  )}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Detailed Configuration Box for Selected Provider */}
      <div className="p-6 rounded-3xl bg-slate-950/90 border border-purple-900/40 shadow-2xl space-y-5">
        {/* Title Bar with Website Link */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-4 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2.5">
              <h4 className="text-base font-bold text-white flex items-center gap-2">
                <Key className="w-4 h-4 text-pink-400" />
                Configure {currentDef.name}
              </h4>
              <span className="text-[10px] px-2.5 py-0.5 rounded-full bg-purple-950 border border-purple-800 text-purple-300 font-mono">
                {currentDef.badge}
              </span>
              {isActive && (
                <span className="text-[10px] px-2.5 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 font-semibold">
                  Active in Chat
                </span>
              )}
            </div>
            <p className="text-xs text-slate-400 mt-0.5">{currentDef.description}</p>
          </div>

          <a
            href={currentDef.websiteUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-pink-500/30 bg-pink-500/10 hover:bg-pink-500/20 text-pink-300 text-xs font-semibold transition-colors shrink-0"
          >
            <span>Get API Key from {currentDef.tagline}</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>

        {/* Inputs */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          {/* API Key */}
          <div className="space-y-1.5 md:col-span-2">
            <div className="flex items-center justify-between">
              <label className="font-semibold text-slate-300 flex items-center gap-1.5">
                <Lock className="w-3.5 h-3.5 text-pink-400" />
                API Key for {currentDef.name}
              </label>
              <button
                type="button"
                onClick={() => setShowKeyPassword(!showKeyPassword)}
                className="text-[11px] text-slate-400 hover:text-pink-300 flex items-center gap-1"
              >
                {showKeyPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                <span>{showKeyPassword ? 'Hide Key' : 'Show Key'}</span>
              </button>
            </div>
            <div className="relative">
              <input
                type={showKeyPassword ? 'text' : 'password'}
                value={apiKeyInput}
                onChange={(e) => setApiKeyInput(e.target.value)}
                placeholder={`Enter your ${currentDef.name} API key (${currentDef.keyPrefixHint})`}
                className="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-white font-mono text-xs focus:outline-none focus:border-pink-500 focus:ring-1 focus:ring-pink-500/30 shadow-inner pr-10"
              />
            </div>
            <p className="text-[11px] text-slate-500">
              Keys are stored securely in your private database and encrypted environment. Never shared publicly.
            </p>
          </div>

          {/* Model Selection */}
          <div className="space-y-1.5">
            <label className="font-semibold text-slate-300 flex items-center gap-1.5">
              <Cpu className="w-3.5 h-3.5 text-purple-400" />
              Model Name
            </label>
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={modelInput}
                onChange={(e) => setModelInput(e.target.value)}
                placeholder="e.g. gpt-4o, llama-3.3-70b-versatile"
                className="flex-1 px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-white text-xs font-mono focus:outline-none focus:border-pink-500"
              />
              {currentDef.modelOptions.length > 0 && (
                <select
                  value={currentDef.modelOptions.includes(modelInput) ? modelInput : ''}
                  onChange={(e) => e.target.value && setModelInput(e.target.value)}
                  className="px-3 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-white text-xs"
                >
                  <option value="">Presets...</option>
                  {currentDef.modelOptions.map((opt) => (
                    <option key={opt} value={opt}>
                      {opt}
                    </option>
                  ))}
                </select>
              )}
            </div>
          </div>

          {/* Base URL (For Custom & OpenAI-compatible providers) */}
          <div className="space-y-1.5">
            <label className="font-semibold text-slate-300 flex items-center gap-1.5">
              <Globe className="w-3.5 h-3.5 text-blue-400" />
              API Base URL
            </label>
            <input
              type="text"
              value={baseUrlInput}
              onChange={(e) => setBaseUrlInput(e.target.value)}
              placeholder={currentDef.defaultBaseUrl || 'https://api.openai.com/v1'}
              className="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-white text-xs font-mono focus:outline-none focus:border-pink-500"
            />
          </div>

          {/* Custom Headers (Optional, useful for custom proxies or OpenRouter) */}
          {selectedProviderId === 'custom' && (
            <div className="space-y-1.5 md:col-span-2">
              <label className="font-semibold text-slate-300">
                Custom Headers (Optional JSON e.g. &#123;"X-Custom-Auth": "value"&#125;)
              </label>
              <input
                type="text"
                value={customHeadersInput}
                onChange={(e) => setCustomHeadersInput(e.target.value)}
                placeholder='{"Authorization": "Bearer token"}'
                className="w-full px-4 py-2 rounded-xl bg-slate-900 border border-slate-800 text-white text-xs font-mono"
              />
            </div>
          )}
        </div>

        {/* Live Test Results Card */}
        {testResult && (
          <div
            className={`p-4 rounded-2xl border transition-all animate-fadeIn ${
              testResult.success
                ? 'bg-emerald-950/30 border-emerald-500/40 text-emerald-200'
                : 'bg-rose-950/30 border-rose-500/40 text-rose-200'
            }`}
          >
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-start gap-2.5">
                {testResult.success ? (
                  <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                ) : (
                  <AlertCircle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
                )}
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <strong className="text-sm font-bold">
                      {testResult.success
                        ? '✅ Connection Verified & Key Active!'
                        : '❌ Connection Test Failed'}
                    </strong>
                    {testResult.latencyMs !== undefined && (
                      <span className="text-[11px] font-mono px-2 py-0.5 rounded-md bg-black/40 border border-emerald-500/30 text-emerald-300">
                        {testResult.latencyMs} ms
                      </span>
                    )}
                  </div>

                  <p className="text-xs opacity-90">
                    {testResult.success
                      ? testResult.message || `Model "${testResult.model}" replied: "${testResult.response}"`
                      : `Error: ${testResult.error}`}
                  </p>

                  <span className="text-[10px] text-slate-400 block">
                    Tested at: {testResult.testedAt}
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-800">
          <div className="flex items-center gap-2">
            {/* The Live Key Test Button */}
            <button
              onClick={handleTestConnection}
              disabled={isTesting}
              className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-xs transition-all shadow-lg active:scale-95 ${
                isTesting
                  ? 'bg-purple-800/50 text-purple-300 cursor-wait'
                  : 'bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white shadow-emerald-500/20'
              }`}
            >
              <Zap className={`w-4 h-4 ${isTesting ? 'animate-spin' : ''}`} />
              <span>{isTesting ? 'Testing Connection & Ping...' : '⚡ Check / Test API Key'}</span>
            </button>
          </div>

          <div className="flex items-center gap-2">
            {/* Save Config Button */}
            <button
              onClick={() => handleSaveProviderConfig(false)}
              className="px-4 py-2.5 rounded-xl border border-slate-700 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold transition-all"
            >
              Save Key
            </button>

            {/* Set As Active Provider Button */}
            <button
              onClick={() => handleSaveProviderConfig(true)}
              className={`flex items-center gap-1.5 px-5 py-2.5 rounded-xl text-xs font-bold transition-all shadow-lg active:scale-95 ${
                isActive
                  ? 'bg-slate-800 text-emerald-400 border border-emerald-500/30'
                  : 'bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 hover:to-purple-500 text-white shadow-pink-500/20'
              }`}
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>{isActive ? 'Current Active Engine' : `Use ${currentDef.name} For Chat`}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
