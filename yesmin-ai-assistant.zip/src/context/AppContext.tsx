import React, { createContext, useContext, useState, useEffect } from 'react';
import { AssistantSettings, UserProfile } from '../types';
import { api } from '../services/api';
import { DEFAULT_ASSISTANT_NAME, DEFAULT_NICKNAME } from '../utils/personality';

export type TabType =
  | 'home'
  | 'chat'
  | 'live'
  | 'code'
  | 'actions'
  | 'search'
  | 'files'
  | 'memory'
  | 'projects'
  | 'tasks'
  | 'settings';

export type AssistantStatus = 'idle' | 'listening' | 'thinking' | 'speaking';

export interface ToastMessage {
  id: string;
  text: string;
  type: 'info' | 'success' | 'warning' | 'error';
}

interface AppContextType {
  settings: AssistantSettings;
  user: UserProfile | null;
  activeTab: TabType;
  setActiveTab: (tab: TabType) => void;
  assistantStatus: AssistantStatus;
  setAssistantStatus: (st: AssistantStatus) => void;
  currentConversationId: string;
  setCurrentConversationId: (id: string) => void;
  updateSettings: (newSettings: Partial<AssistantSettings>) => Promise<void>;
  resetAssistantName: () => Promise<void>;
  updateUser: (user: UserProfile) => void;
  showToast: (text: string, type?: ToastMessage['type']) => void;
  toasts: ToastMessage[];
  removeToast: (id: string) => void;
  triggerNotification: (title: string, body: string) => void;
}

const defaultSettings: AssistantSettings = {
  assistantName: DEFAULT_ASSISTANT_NAME,
  userNickname: DEFAULT_NICKNAME,
  personalityMode: 'girlfriend',
  greetingStyle: 'romantic',
  customInstructions: '',
  systemPromptMode: 'preset',
  activePromptPreset: 'girlfriend_romantic',
  voiceProvider: 'browser',
  voiceName: 'Default',
  voiceSpeed: 1,
  autoSpeak: false,
  volume: 1,
  liveVoiceModel: 'gemini-3.8-live',
  liveVoiceName: 'Zephyr',
  interruptMode: true,
  language: 'hinglish',
  activeProvider: 'gemini',
  geminiModel: 'gemini-3.8-flash',
  temperature: 0.7,
  maxOutputTokens: 2048,
  theme: 'dark',
  accentColor: 'pink',
  glowIntensity: 'vibrant',
  animationIntensity: 'medium',
  memoryEnabled: true,
  micPermission: false,
  notifPermission: false,
  cameraPermission: false,
};

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [settings, setSettings] = useState<AssistantSettings>(defaultSettings);
  const [user, setUser] = useState<UserProfile | null>(null);
  const [activeTab, setActiveTab] = useState<TabType>('home');
  const [assistantStatus, setAssistantStatus] = useState<AssistantStatus>('idle');
  const [currentConversationId, setCurrentConversationId] = useState<string>('conv_welcome');
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  // Load persistent settings on mount
  useEffect(() => {
    async function loadInitial() {
      try {
        const data = await api.getSettings();
        if (data.settings) {
          setSettings((prev) => ({ ...prev, ...data.settings }));
        }
        if (data.user) {
          setUser(data.user);
        }
      } catch (err) {
        console.warn('Initial load fallback to defaults:', err);
      }
    }
    loadInitial();
  }, []);

  const showToast = (text: string, type: ToastMessage['type'] = 'info') => {
    const id = `toast_${Date.now()}_${Math.random().toString(36).substring(2, 5)}`;
    setToasts((prev) => [...prev, { id, text, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4000);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  const updateSettings = async (newSettings: Partial<AssistantSettings>) => {
    const updated = { ...settings, ...newSettings };
    setSettings(updated);
    try {
      await api.saveSettings(newSettings);
      showToast('Settings saved successfully', 'success');
    } catch (err: any) {
      showToast(err.message || 'Failed to save settings', 'error');
    }
  };

  const resetAssistantName = async () => {
    await updateSettings({ assistantName: DEFAULT_ASSISTANT_NAME });
    showToast(`Assistant name reset to "${DEFAULT_ASSISTANT_NAME}"`, 'info');
  };

  const updateUser = (u: UserProfile) => {
    setUser(u);
  };

  const triggerNotification = (title: string, body: string) => {
    showToast(`${title}: ${body}`, 'info');
    if (typeof window !== 'undefined' && 'Notification' in window) {
      if (Notification.permission === 'granted') {
        try {
          new Notification(title, {
            body,
            icon: '/icon.png',
          });
        } catch {}
      } else if (Notification.permission !== 'denied') {
        Notification.requestPermission().then((perm) => {
          if (perm === 'granted') {
            new Notification(title, { body });
          }
        });
      }
    }
  };

  return (
    <AppContext.Provider
      value={{
        settings,
        user,
        activeTab,
        setActiveTab,
        assistantStatus,
        setAssistantStatus,
        currentConversationId,
        setCurrentConversationId,
        updateSettings,
        resetAssistantName,
        updateUser,
        showToast,
        toasts,
        removeToast,
        triggerNotification,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within AppProvider');
  return context;
};
