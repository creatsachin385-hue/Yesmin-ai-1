package com.yesmin.ai.assistant;

import android.Manifest;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.http.SslError;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.webkit.PermissionRequest;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {

    private WebView webView;
    private ProgressBar progressBar;
    private LinearLayout errorLayout;
    private TextView errorTitle;
    private TextView errorMessage;
    private TextView currentUrlText;
    private Button btnLoadLocal;
    private Button btnRetry;
    private Button btnChangeUrl;

    private String currentServerUrl;
    private boolean pageLoadedSuccessfully = false;
    private final Handler timeoutHandler = new Handler(Looper.getMainLooper());
    private static final int TIMEOUT_MS = 10000;
    private static final int PERMISSION_REQUEST_CODE = 1001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webView);
        progressBar = findViewById(R.id.progressBar);
        errorLayout = findViewById(R.id.errorLayout);
        errorTitle = findViewById(R.id.errorTitle);
        errorMessage = findViewById(R.id.errorMessage);
        currentUrlText = findViewById(R.id.currentUrlText);
        btnLoadLocal = findViewById(R.id.btnLoadLocal);
        btnRetry = findViewById(R.id.btnRetry);
        btnChangeUrl = findViewById(R.id.btnChangeUrl);

        SharedPreferences prefs = getSharedPreferences("yesmin_config", MODE_PRIVATE);
        String defaultUrl = getString(R.string.app_url);
        currentServerUrl = prefs.getString("server_url", defaultUrl);

        setupWebView();
        setupErrorActions();
        requestNecessaryPermissions();

        loadTargetUrl(currentServerUrl);
    }

    private void setupWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setAllowUniversalAccessFromFileURLs(true);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }

        // Use modern Chrome mobile user agent so Cloud Run proxy / Google doesn't block WebView
        String chromeUa = "Mozilla/5.0 (Linux; Android 14; Mobile; rv:125.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36 YesminAI/1.0";
        settings.setUserAgentString(chromeUa);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                progressBar.setVisibility(View.VISIBLE);
                pageLoadedSuccessfully = false;

                // Start timeout timer
                timeoutHandler.removeCallbacksAndMessages(null);
                timeoutHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (!pageLoadedSuccessfully && !isFinishing()) {
                            showErrorState("Server Connection Timeout", 
                                "The cloud server is taking too long to respond. You can launch the local bundled app or retry.");
                        }
                    }
                }, TIMEOUT_MS);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                progressBar.setVisibility(View.GONE);
                timeoutHandler.removeCallbacksAndMessages(null);
                pageLoadedSuccessfully = true;

                // If loaded without error, ensure error layout is hidden
                if (errorLayout.getVisibility() == View.VISIBLE && !url.contains("error")) {
                    errorLayout.setVisibility(View.GONE);
                    webView.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    timeoutHandler.removeCallbacksAndMessages(null);
                    showErrorState("Network Connection Error", 
                        "Could not connect to: " + request.getUrl().toString() + "\n(" + error.getDescription() + ")");
                }
            }

            @Override
            public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse errorResponse) {
                if (request.isForMainFrame() && errorResponse.getStatusCode() >= 400) {
                    timeoutHandler.removeCallbacksAndMessages(null);
                    showErrorState("HTTP " + errorResponse.getStatusCode() + " Error", 
                        "The server returned an HTTP error code. The dev server may be sleeping.");
                }
            }

            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                // Proceed through SSL certificates in development/preview environments
                handler.proceed();
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        request.grant(request.getResources());
                    }
                });
            }

            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                if (newProgress >= 90) {
                    progressBar.setVisibility(View.GONE);
                }
            }
        });
    }

    private void setupErrorActions() {
        btnLoadLocal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadLocalBundledApp();
            }
        });

        btnRetry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadTargetUrl(currentServerUrl);
            }
        });

        btnChangeUrl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showChangeUrlDialog();
            }
        });
    }

    private void loadTargetUrl(String url) {
        currentServerUrl = url;
        currentUrlText.setText("URL: " + url);
        errorLayout.setVisibility(View.GONE);
        webView.setVisibility(View.VISIBLE);
        progressBar.setVisibility(View.VISIBLE);
        webView.loadUrl(url);
    }

    private void loadLocalBundledApp() {
        errorLayout.setVisibility(View.GONE);
        webView.setVisibility(View.VISIBLE);
        progressBar.setVisibility(View.VISIBLE);
        Toast.makeText(this, "Launching local bundled Yesmin AI...", Toast.LENGTH_SHORT).show();
        webView.loadUrl("file:///android_asset/dist/index.html");
    }

    private void showErrorState(String title, String message) {
        progressBar.setVisibility(View.GONE);
        errorTitle.setText(title);
        errorMessage.setText(message);
        currentUrlText.setText("URL: " + currentServerUrl);
        errorLayout.setVisibility(View.VISIBLE);
    }

    private void showChangeUrlDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Configure Server URL");
        builder.setMessage("Enter the web URL for your Yesmin AI instance:");

        final EditText input = new EditText(this);
        input.setText(currentServerUrl);
        input.setSelection(currentServerUrl.length());
        builder.setView(input);

        builder.setPositiveButton("Save & Connect", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String newUrl = input.getText().toString().trim();
                if (!newUrl.isEmpty()) {
                    if (!newUrl.startsWith("http://") && !newUrl.startsWith("https://")) {
                        newUrl = "https://" + newUrl;
                    }
                    SharedPreferences prefs = getSharedPreferences("yesmin_config", MODE_PRIVATE);
                    prefs.edit().putString("server_url", newUrl).apply();
                    loadTargetUrl(newUrl);
                }
            }
        });

        builder.setNeutralButton("Reset Default", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String defaultUrl = getString(R.string.app_url);
                SharedPreferences prefs = getSharedPreferences("yesmin_config", MODE_PRIVATE);
                prefs.edit().putString("server_url", defaultUrl).apply();
                loadTargetUrl(defaultUrl);
            }
        });

        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    private void requestNecessaryPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            String[] permissions = {
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.CAMERA,
                Manifest.permission.MODIFY_AUDIO_SETTINGS
            };

            boolean needRequest = false;
            for (String perm : permissions) {
                if (ContextCompat.checkSelfPermission(this, perm) != PackageManager.PERMISSION_GRANTED) {
                    needRequest = true;
                    break;
                }
            }

            if (needRequest) {
                ActivityCompat.requestPermissions(this, permissions, PERMISSION_REQUEST_CODE);
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        timeoutHandler.removeCallbacksAndMessages(null);
        if (webView != null) {
            webView.destroy();
        }
        super.onDestroy();
    }
}
