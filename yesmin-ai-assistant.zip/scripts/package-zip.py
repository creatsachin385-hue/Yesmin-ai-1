import zipfile
import os

output_zip = 'public/yesmin-ai-assistant.zip'
items_to_zip = [
    'android',
    'package.json',
    'vite.config.ts',
    'tsconfig.json',
    'tsconfig.node.json',
    'index.html',
    'src',
    '.github'
]

exclude_patterns = ['node_modules', '.git', '__pycache__', '.DS_Store', 'build', '.gradle']

def should_exclude(path):
    for pat in exclude_patterns:
        if pat in path.split(os.sep):
            return True
    return False

os.makedirs('public', exist_ok=True)
os.makedirs('dist', exist_ok=True)

with zipfile.ZipFile(output_zip, 'w', zipfile.ZIP_DEFLATED) as zipf:
    for item in items_to_zip:
        if os.path.isfile(item):
            zipf.write(item, arcname=item)
            print(f"Added file: {item}")
        elif os.path.isdir(item):
            for root, dirs, files in os.walk(item):
                dirs[:] = [d for d in dirs if not should_exclude(os.path.join(root, d))]
                for file in files:
                    file_path = os.path.join(root, file)
                    if not should_exclude(file_path):
                        zipf.write(file_path, arcname=file_path)
            print(f"Added directory: {item}")

# Also copy to dist if dist exists
if os.path.exists('dist'):
    import shutil
    shutil.copyfile(output_zip, 'dist/yesmin-ai-assistant.zip')

print(f"Successfully created {output_zip} ({os.path.getsize(output_zip)} bytes)")
